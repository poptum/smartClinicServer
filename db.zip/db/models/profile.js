module.exports = (sequelize, DataTypes) => {
  const profile = sequelize.define('profile', {
  	id: {
      type: db.Sequelize.INTEGER,
      primaryKey: true
    },
    profile: {
      type: db.Sequelize.STRING,
    },
  });

  // profile.associate = (models) => {
    // profile.hasMany(models.profileItem, {
    //   foreignKey: 'profileId',
    //   as: 'profileItems',
    // });
  // };

  return profile;
};